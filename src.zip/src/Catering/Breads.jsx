// src/Catering/Breads.jsx
import React from "react";
import { CateringCategoryContent } from "./CateringLayout";


const Breads = () => {
    return (
        <CateringCategoryContent
            categoryId="67578cce4c44619f292eb24e"
            titleOverride="Breads"
        />
    );
};

export default Breads;