// src/Catering/Entrees.jsx
import React from "react";
import { CateringCategoryContent } from "./CateringLayout";


const Entrees = () => {
    return (
        <CateringCategoryContent
            categoryId="640f4d897ff120faa849e5bd"
            titleOverride="Entrees"
        />
    );
};

export default Entrees;