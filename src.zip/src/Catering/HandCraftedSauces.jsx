// src/Catering/HandCraftedSauces.jsx
import React from "react";
import { CateringCategoryContent } from "./CateringLayout";


const HandCraftedSauces = () => {
    return (
        <CateringCategoryContent
            categoryId="665de437cdd47868117abcff"
            titleOverride="Hand-crafted Sauces"
        />
    );
};

export default HandCraftedSauces;