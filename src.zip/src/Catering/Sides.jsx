// src/Catering/Sides.jsx
import React from "react";
import { CateringCategoryContent } from "./CateringLayout";


const Sides = () => {
    return (
        <CateringCategoryContent
            categoryId="640f4d897ff120faa849e5be"
            titleOverride="Sides"
        />
    );
};

export default Sides;