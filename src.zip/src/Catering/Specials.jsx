// src/Catering/Specials.jsx
import React from "react";
import { CateringCategoryContent } from "./CateringLayout";

const Specials = () => {
    return (
        <CateringCategoryContent
            categoryId="640f4d897ff120faa849e5bf"
            titleOverride="Specials"
        />
    );
};

export default Specials;