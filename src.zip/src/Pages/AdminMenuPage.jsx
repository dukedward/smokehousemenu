// src/AdminMenuPage.jsx
import React, { useEffect, useState } from "react";
import {
    collection,
    getDocs,
    addDoc,
    updateDoc,
    deleteDoc,
    doc,
    query,
    where,
    orderBy,
} from "firebase/firestore";
import { db } from "../firebaseConfig";

const AdminMenuPage = () => {
    // Categories
    const [categories, setCategories] = useState([]);
    const [catLoading, setCatLoading] = useState(true);
    const [catForm, setCatForm] = useState({
        id: "",
        name: "",
        type: "small", // "small" | "catering"
        hasSubSection: false,
        isTray: false,
    });
    const [catMode, setCatMode] = useState("add"); // "add" | "edit"

    // Products
    const [selectedCategoryId, setSelectedCategoryId] = useState("");
    const [products, setProducts] = useState([]);
    const [prodLoading, setProdLoading] = useState(false);
    const [prodForm, setProdForm] = useState({
        id: "",
        name: "",
        price: "",
        active: true,
    });
    const [prodMode, setProdMode] = useState("add"); // "add" | "edit"

    // Load all categories on mount
    useEffect(() => {
        const loadCategories = async () => {
            setCatLoading(true);
            const snap = await getDocs(
                query(collection(db, "categories"), orderBy("name"))
            );
            const data = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
            setCategories(data);
            setCatLoading(false);
        };
        loadCategories();
    }, []);

    // Load products when selected category changes
    useEffect(() => {
        const loadProducts = async () => {
            if (!selectedCategoryId) {
                setProducts([]);
                return;
            }
            setProdLoading(true);
            const snap = await getDocs(
                query(
                    collection(db, "products"),
                    where("categoryId", "==", selectedCategoryId),
                    orderBy("name")
                )
            );
            const data = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
            setProducts(data);
            setProdLoading(false);
        };
        loadProducts();
    }, [selectedCategoryId]);

    // ===== Category Handlers =====

    const resetCatForm = () => {
        setCatForm({
            id: "",
            name: "",
            type: "small",
            hasSubSection: false,
            isTray: false,
        });
        setCatMode("add");
    };

    const handleCatChange = (e) => {
        const { name, value, type, checked } = e.target;
        setCatForm((f) => ({
            ...f,
            [name]: type === "checkbox" ? checked : value,
        }));
    };

    const handleCatSubmit = async (e) => {
        e.preventDefault();
        if (!catForm.name.trim()) return;

        if (catMode === "add") {
            await addDoc(collection(db, "categories"), {
                name: catForm.name.trim(),
                type: catForm.type,
                hasSubSection: !!catForm.hasSubSection,
                isTray: !!catForm.isTray,
            });
        } else {
            const ref = doc(db, "categories", catForm.id);
            await updateDoc(ref, {
                name: catForm.name.trim(),
                type: catForm.type,
                hasSubSection: !!catForm.hasSubSection,
                isTray: !!catForm.isTray,
            });
        }

        // Reload categories
        const snap = await getDocs(
            query(collection(db, "categories"), orderBy("name"))
        );
        const data = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        setCategories(data);
        resetCatForm();
    };

    const handleCatEditClick = (cat) => {
        setCatForm({
            id: cat.id,
            name: cat.name,
            type: cat.type || "small",
            hasSubSection: !!cat.hasSubSection,
            isTray: !!cat.isTray,
        });
        setCatMode("edit");
    };

    const handleCatDelete = async (catId) => {
        if (!window.confirm("Delete this category? Products will remain orphaned.")) {
            return;
        }
        await deleteDoc(doc(db, "categories", catId));
        setCategories((prev) => prev.filter((c) => c.id !== catId));
        if (selectedCategoryId === catId) {
            setSelectedCategoryId("");
            setProducts([]);
        }
    };

    // ===== Product Handlers =====

    const resetProdForm = () => {
        setProdForm({
            id: "",
            name: "",
            price: "",
            active: true,
        });
        setProdMode("add");
    };

    const handleProdChange = (e) => {
        const { name, value, type, checked } = e.target;
        setProdForm((f) => ({
            ...f,
            [name]: type === "checkbox" ? checked : value,
        }));
    };

    const handleProdSubmit = async (e) => {
        e.preventDefault();
        if (!selectedCategoryId) {
            alert("Select a category first.");
            return;
        }
        if (!prodForm.name.trim()) return;

        const payload = {
            name: prodForm.name.trim(),
            price: parseFloat(prodForm.price || "0"),
            categoryId: selectedCategoryId,
            active: !!prodForm.active,
        };

        if (prodMode === "add") {
            await addDoc(collection(db, "products"), payload);
        } else {
            const ref = doc(db, "products", prodForm.id);
            await updateDoc(ref, payload);
        }

        // Reload products
        const snap = await getDocs(
            query(
                collection(db, "products"),
                where("categoryId", "==", selectedCategoryId),
                orderBy("name")
            )
        );
        const data = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        setProducts(data);
        resetProdForm();
    };

    const handleProdEditClick = (p) => {
        setProdForm({
            id: p.id,
            name: p.name,
            price: p.price?.toString() || "",
            active: !!p.active,
        });
        setProdMode("edit");
    };

    const handleProdDelete = async (prodId) => {
        if (!window.confirm("Delete this product?")) return;
        await deleteDoc(doc(db, "products", prodId));
        setProducts((prev) => prev.filter((p) => p.id !== prodId));
        if (prodForm.id === prodId) {
            resetProdForm();
        }
    };

    return (
        <section className="screen">
            <h1>Admin Menu Management</h1>
            <p className="screen-subtitle">
                Only admins can access this page. Manage categories and products below.
            </p>

            {/* CATEGORIES SECTION */}
            <div className="admin-grid">
                <div className="admin-panel">
                    <h2>Categories</h2>

                    {catLoading ? (
                        <p>Loading categories…</p>
                    ) : (
                        <ul className="admin-list">
                            {categories.map((cat) => (
                                <li key={cat.id} className="admin-list-item">
                                    <button
                                        type="button"
                                        className={`tag ${selectedCategoryId === cat.id ? "tag-active" : ""
                                            }`}
                                        onClick={() => setSelectedCategoryId(cat.id)}
                                    >
                                        {cat.name} <span className="tag-pill">{cat.type}</span>
                                    </button>
                                    <div className="admin-item-actions">
                                        <button
                                            type="button"
                                            onClick={() => handleCatEditClick(cat)}
                                        >
                                            Edit
                                        </button>
                                        <button
                                            type="button"
                                            className="danger-text"
                                            onClick={() => handleCatDelete(cat.id)}
                                        >
                                            Delete
                                        </button>
                                    </div>
                                </li>
                            ))}
                            {categories.length === 0 && (
                                <li>No categories yet. Create one below.</li>
                            )}
                        </ul>
                    )}
                </div>

                <div className="admin-panel">
                    <h2>{catMode === "add" ? "Add Category" : "Edit Category"}</h2>
                    <form className="form" onSubmit={handleCatSubmit}>
                        <label>
                            Name
                            <input
                                name="name"
                                value={catForm.name}
                                onChange={handleCatChange}
                                required
                            />
                        </label>

                        <label>
                            Type
                            <select
                                name="type"
                                value={catForm.type}
                                onChange={handleCatChange}
                            >
                                <option value="small">Small Plates</option>
                                <option value="catering">Catering</option>
                            </select>
                        </label>

                        <label className="checkbox-row">
                            <input
                                type="checkbox"
                                name="hasSubSection"
                                checked={catForm.hasSubSection}
                                onChange={handleCatChange}
                            />
                            Has Sub-Sections
                        </label>

                        <label className="checkbox-row">
                            <input
                                type="checkbox"
                                name="isTray"
                                checked={catForm.isTray}
                                onChange={handleCatChange}
                            />
                            Is Tray (Catering style)
                        </label>

                        <div className="form-row-actions">
                            <button type="submit" className="primary-btn">
                                {catMode === "add" ? "Create Category" : "Save Changes"}
                            </button>
                            {catMode === "edit" && (
                                <button
                                    type="button"
                                    className="secondary-btn"
                                    onClick={resetCatForm}
                                >
                                    Cancel
                                </button>
                            )}
                        </div>
                    </form>
                </div>
            </div>

            {/* PRODUCTS SECTION */}
            <hr style={{ margin: "1.5rem 0" }} />

            <div className="admin-grid">
                <div className="admin-panel">
                    <h2>Products</h2>

                    <label className="form">
                        <span>Category for products</span>
                        <select
                            value={selectedCategoryId}
                            onChange={(e) => setSelectedCategoryId(e.target.value)}
                        >
                            <option value="">-- Select a category --</option>
                            {categories.map((c) => (
                                <option key={c.id} value={c.id}>
                                    {c.name} ({c.type})
                                </option>
                            ))}
                        </select>
                    </label>

                    {selectedCategoryId ? (
                        prodLoading ? (
                            <p>Loading products…</p>
                        ) : (
                            <ul className="admin-list">
                                {products.map((p) => (
                                    <li key={p.id} className="admin-list-item">
                                        <div>
                                            <strong>{p.name}</strong>{" "}
                                            {typeof p.price === "number" && p.price > 0 && (
                                                <span> - ${p.price.toFixed(2)}</span>
                                            )}{" "}
                                            {!p.active && (
                                                <span className="muted-pill">inactive</span>
                                            )}
                                        </div>
                                        <div className="admin-item-actions">
                                            <button
                                                type="button"
                                                onClick={() => handleProdEditClick(p)}
                                            >
                                                Edit
                                            </button>
                                            <button
                                                type="button"
                                                className="danger-text"
                                                onClick={() => handleProdDelete(p.id)}
                                            >
                                                Delete
                                            </button>
                                        </div>
                                    </li>
                                ))}
                                {products.length === 0 && (
                                    <li>No products yet for this category.</li>
                                )}
                            </ul>
                        )
                    ) : (
                        <p>Select a category to view products.</p>
                    )}
                </div>

                <div className="admin-panel">
                    <h2>{prodMode === "add" ? "Add Product" : "Edit Product"}</h2>
                    <form className="form" onSubmit={handleProdSubmit}>
                        <label>
                            Name
                            <input
                                name="name"
                                value={prodForm.name}
                                onChange={handleProdChange}
                                required
                            />
                        </label>

                        <label>
                            Price
                            <input
                                type="number"
                                step="0.01"
                                name="price"
                                value={prodForm.price}
                                onChange={handleProdChange}
                            />
                        </label>

                        <label className="checkbox-row">
                            <input
                                type="checkbox"
                                name="active"
                                checked={prodForm.active}
                                onChange={handleProdChange}
                            />
                            Active
                        </label>

                        <div className="form-row-actions">
                            <button type="submit" className="primary-btn">
                                {prodMode === "add" ? "Create Product" : "Save Product"}
                            </button>
                            {prodMode === "edit" && (
                                <button
                                    type="button"
                                    className="secondary-btn"
                                    onClick={resetProdForm}
                                >
                                    Cancel
                                </button>
                            )}
                        </div>
                    </form>
                </div>
            </div>
        </section>
    );
};

export default AdminMenuPage;