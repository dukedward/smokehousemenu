// src/App.jsx
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import "./App.css";

import Home from "./Pages/Home";

// Small Plates
import SmallPlatesLayout from "./SmallPlates/SmallPlatesLayout";
import BBQEntrees from "./SmallPlates/BBQEntrees";
import FriedEntrees from "./SmallPlates/FriedEntrees";
import BurgersSandwiches from "./SmallPlates/BurgersSandwiches";
import SmallSides from "./SmallPlates/Sides";
import SmallBeverages from "./SmallPlates/Beverages";
import SmallSpecials from "./SmallPlates/Specials";

// Catering
import CateringLayout from "./Catering/CateringLayout";
import CateringEntrees from "./Catering/Entrees";
import CateringSides from "./Catering/Sides";
import HandCraftedSauces from "./Catering/HandCraftedSauces";
import CateringBeverages from "./Catering/Beverages";
import Breads from "./Catering/Breads";
import CateringSpecials from "./Catering/Specials";

function App() {
    return (
        <Router>
            <div className="app-root">
                <header className="app-header">
                    <Link to="/" className="chef-icon" aria-label="Home">
                        <svg
                            width="26"
                            height="26"
                            viewBox="0 0 64 64"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="4"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                        >
                            <path d="M20 28H44V50H20z" />
                            <path d="M14 22C12 18 15 12 22 12C28 8 36 8 42 12C49 12 52 18 50 22C52 26 50 30 46 30H18C14 30 12 26 14 22Z" />
                        </svg>
                    </Link>
                    <Link to="/" className="brand">
                        <span className="brand-title">4 The Fork Of IT</span>
                        <span className="brand-tagline">BBQ • Comfort • Catering</span>
                    </Link>
                </header>

                <main className="app-main">
                    <Routes>
                        <Route path="/" element={<Home />} />

                        {/* Small Plates nested routes */}
                        <Route path="/small-plates" element={<SmallPlatesLayout />}>
                            <Route index element={<BBQEntrees />} />
                            <Route path="bbq-entrees" element={<BBQEntrees />} />
                            <Route path="fried-entrees" element={<FriedEntrees />} />
                            <Route
                                path="burgers-sandwiches"
                                element={<BurgersSandwiches />}
                            />
                            <Route path="sides" element={<SmallSides />} />
                            <Route path="beverages" element={<SmallBeverages />} />
                            <Route path="specials" element={<SmallSpecials />} />
                        </Route>

                        {/* Catering nested routes */}
                        <Route path="/catering" element={<CateringLayout />}>
                            <Route index element={<CateringEntrees />} />
                            <Route path="entrees" element={<CateringEntrees />} />
                            <Route path="sides" element={<CateringSides />} />
                            <Route
                                path="hand-crafted-sauces"
                                element={<HandCraftedSauces />}
                            />
                            <Route path="beverages" element={<CateringBeverages />} />
                            <Route path="breads" element={<Breads />} />
                            <Route path="specials" element={<CateringSpecials />} />
                        </Route>
                    </Routes>
                </main>
            </div>
        </Router>
    );
}

export default App;